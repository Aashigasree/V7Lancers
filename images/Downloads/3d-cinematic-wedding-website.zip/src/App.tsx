/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, 
  MapPin, 
  Calendar, 
  ArrowDown, 
  Clock, 
  Compass, 
  Sparkles, 
  Flower, 
  Music, 
  Menu, 
  X, 
  ChevronRight, 
  ChevronLeft, 
  ExternalLink 
} from 'lucide-react';

import { WEDDING_EVENTS, GALLERY_MOMENTS, VENUE_DETAILS, BRIDE_NAME, GROOM_NAME, WEDDING_DATE, WEDDING_LOCATION } from './data';
import TiltCard from './components/TiltCard';
import ParticleCanvas from './components/ParticleCanvas';
import AudioPlayer from './components/AudioPlayer';
import RsvpForm from './components/RsvpForm';

export default function App() {
  const [scrollY, setScrollY] = useState(0);
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('hero');
  
  // Gallery Lightbox Modal State
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Scroll tracking with RAF for fluid motion
  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setScrollY(window.scrollY);
          setIsScrolled(window.scrollY > 60);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Section highlighting on scroll
  useEffect(() => {
    const sections = ['hero', 'welcome', 'story', 'events', 'venue', 'gallery', 'rsvp'];
    const handleViewport = () => {
      const scrollPos = window.scrollY + 200;
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveTab(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleViewport, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleViewport);
    };
  }, []);

  // Scroll to helper
  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  // Intersection observer for fading elements elegantly
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-8');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );

    const elements = document.querySelectorAll('.scroll-reveal');
    elements.forEach((el) => observer.observe(el));

    return () => {
      elements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  // Handle slide transitions in Lightbox
  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex + 1) % GALLERY_MOMENTS.length);
    }
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex - 1 + GALLERY_MOMENTS.length) % GALLERY_MOMENTS.length);
    }
  };

  // Background Video scale based on scroll depth
  const videoScale = 1.02 + scrollY * 0.00018;
  const videoOpacity = Math.max(0.2, 1 - scrollY / 1200);

  return (
    <div className="relative min-h-screen text-gold-900 bg-[#0c0a06] transition-colors duration-500 overflow-x-hidden pt-20">
      
      {/* Immersive 3D Parallax Background Video and Blurring Overlay */}
      <div className="fixed inset-0 w-full h-full -z-30 overflow-hidden bg-black pointer-events-none">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover origin-center transition-transform duration-[100ms] ease-out select-none"
          style={{
            transform: `scale(${videoScale}) translateY(${scrollY * 0.04}px)`,
            opacity: videoOpacity,
            filter: `brightness(0.72) contrast(1.04) saturate(1.1) blur(${Math.min(6, scrollY * 0.005)}px)`
          }}
        >
          <source 
            src="./Bride_and_groom_exchange_garlands_202606121250.mp4" 
            type="video/mp4" 
          />
          Your browser does not support the video tag.
        </video>
      </div>

      {/* Luxury Cinematic Gradations & Warm Lighting over dynamic video */}
      <div className="cinematic-vignette" />

      {/* Floating 3D Reactive Interactive Canvas Dust & Jasmine layer */}
      <ParticleCanvas scrollY={scrollY} />

      {/* BACKGROUND MUSIC INTEGRATION - Customizable Floating Instrumentals */}
      <AudioPlayer />

      {/* TOP HEADER NAVIGATION */}
      <header 
        className={`fixed top-0 left-0 right-0 z-50 h-20 transition-all duration-300 ${
          isScrolled 
            ? 'silk-glass py-3 h-16 shadow-lg border-b border-gold-300' 
            : 'bg-transparent py-5 border-b border-gold-400/10'
        }`}
      >
        <div className="max-w-6xl mx-auto h-full px-6 flex items-center justify-between">
          {/* Logo signature */}
          <button 
            onClick={() => scrollToSection('hero')} 
            className="flex items-center gap-1.5 focus:outline-none cursor-pointer"
          >
            <span className="font-cinzel text-lg md:text-xl font-bold tracking-widest text-gold-950">
              {BRIDE_NAME} <span className="text-gold-500 font-serif font-light">&amp;</span> {GROOM_NAME}
            </span>
          </button>

          {/* Desktop Links */}
          <nav className="hidden md:flex items-center gap-8">
            {[
              { id: 'story', label: 'Our Story' },
              { id: 'events', label: 'Celebration' },
              { id: 'venue', label: 'Destination' },
              { id: 'gallery', label: 'Gallery' },
              { id: 'rsvp', label: 'RSVP' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => scrollToSection(tab.id)}
                className={`text-xs uppercase font-semibold font-sans tracking-widest relative py-1 focus:outline-none transition-colors duration-300 cursor-pointer ${
                  activeTab === tab.id 
                    ? 'text-gold-900 font-bold' 
                    : 'text-gold-850 hover:text-gold-600'
                }`}
              >
                {tab.label}
                <span 
                  className={`absolute bottom-0 left-0 w-full h-[1.5px] bg-gradient-to-r from-gold-500 to-gold-300 transition-transform duration-500 origin-left ${
                    activeTab === tab.id ? 'scale-x-100' : 'scale-x-0'
                  }`} 
                />
              </button>
            ))}
            
            <button 
              onClick={() => scrollToSection('rsvp')}
              className="bg-gradient-to-r from-gold-600 to-gold-500 text-white hover:shadow-lg hover:scale-105 active:scale-100 border border-gold-400/40 text-[10px] font-bold tracking-widest uppercase px-5 py-2 rounded-full cursor-pointer transition-all font-sans"
            >
              Respond
            </button>
          </nav>

          {/* Mobile responsive toggle */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
            className="md:hidden text-gold-950 p-2 focus:outline-none cursor-pointer"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Slideout menu */}
        {mobileMenuOpen && (
          <div className="absolute top-full left-0 right-0 bg-[#fffdf7] border-b border-gold-300 px-6 py-8 flex flex-col gap-4 animate-fade-in shadow-2xl md:hidden text-left border-t border-gold-200">
            {[
              { id: 'story', label: 'Our Story' },
              { id: 'events', label: 'Celebration Schedule' },
              { id: 'venue', label: 'The Destination' },
              { id: 'gallery', label: 'Gallery Moments' },
              { id: 'rsvp', label: 'Secure RSVP Response' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => scrollToSection(tab.id)}
                className={`text-left text-xs uppercase tracking-widest font-bold py-2 border-b border-gold-100 pb-2 flex justify-between items-center ${
                  activeTab === tab.id ? 'text-gold-600' : 'text-gold-800'
                }`}
              >
                <span>{tab.label}</span>
                <ChevronRight className="w-3.5 h-3.5 text-gold-400" />
              </button>
            ))}
            <button 
              onClick={() => scrollToSection('rsvp')}
              className="mt-2 w-full text-center bg-gradient-to-r from-gold-600 to-gold-500 text-white py-3 font-semibold uppercase tracking-widest text-xs rounded shadow"
            >
              Reserve Attendance
            </button>
          </div>
        )}
      </header>

      {/* CORE TIMELINE CONTENT */}
      <main className="relative z-10">

        {/* 1. HERO HOME SECTION */}
        <section 
          id="hero" 
          className="min-h-screen flex items-center justify-center relative px-6 py-12"
        >
          {/* Main Floating Hero invitation plaque */}
          <div 
            id="hero-card" 
            className="max-w-[620px] w-full transition-transform duration-[120ms] ease-out flex flex-col justify-center text-center animate-fade-in h-auto"
            style={{ 
              transform: `translateY(${scrollY * 0.22}px) translateZ(0px)`,
            }}
          >
            <TiltCard scale={1.01} className="w-full">
              <div className="py-12 px-6 md:px-10 flex flex-col items-center">
                <span className="text-[10px] md:text-xs tracking-[0.45em] uppercase font-bold text-gold-600 mb-4 font-sans">
                  Prasannadha Vaikritam • Tying Hearts
                </span>
                
                <h1 className="font-serif text-4xl md:text-6xl text-gold-950 tracking-wide mb-3">
                  {BRIDE_NAME} <span className="text-gold-500 font-light">&amp;</span> {GROOM_NAME}
                </h1>
                
                <div className="w-[120px] h-[1px] bg-gradient-to-r from-transparent via-gold-500 to-transparent relative my-5">
                  <div className="absolute -top-1 left-12 flex h-2 w-2 items-center justify-center">
                    <Heart className="w-2.5 h-2.5 text-gold-600 fill-gold-600" />
                  </div>
                </div>

                <p className="font-serif text-lg md:text-xl text-gold-800 italic font-medium mb-1">
                  Our Auspicious Garland Exchange
                </p>
                <p className="text-[10px] md:text-xs tracking-widest uppercase font-semibold text-gold-600 mb-6 font-sans">
                  {WEDDING_DATE} • {WEDDING_LOCATION}
                </p>
                
                <p className="text-xs text-gold-900/70 max-w-sm mx-auto leading-relaxed italic mb-2 font-serif">
                  "A bond forged across lifespans, tied with sacred golden thread, blessed under a canopy of pure white jasmine."
                </p>
              </div>
            </TiltCard>
          </div>

          {/* Luxury scroll witness prompt */}
          <button 
            onClick={() => scrollToSection('welcome')}
            className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 cursor-pointer bg-transparent focus:outline-none text-gold-700/80 hover:text-gold-600 group"
          >
            <span className="text-[9px] uppercase tracking-[0.25em] font-semibold text-gold-600 group-hover:tracking-[0.35em] transition-all font-sans">
              Scroll to Witness
            </span>
            <div className="w-7 h-10 border border-gold-400 rounded-full p-1 flex justify-center shadow-lg bg-gold-50/20">
              <ArrowDown className="w-3.5 h-3.5 text-gold-600 animate-bounce" />
            </div>
          </button>
        </section>

        {/* 2. TRADITIONAL WELCOME INSCRIPTIONS */}
        <section id="welcome" className="py-24 px-6 max-w-5xl mx-auto">
          <div className="scroll-reveal opacity-0 translate-y-8 transition-all duration-1000 ease-out text-center">
            <TiltCard className="max-w-3xl mx-auto">
              <div className="py-12 px-6 md:px-12 flex flex-col items-center">
                <div className="w-12 h-12 rounded-full border border-gold-300 flex items-center justify-center text-gold-600 mb-5 bg-gold-50/30 animate-pulse">
                  <Flower className="w-5 h-5 text-gold-500" />
                </div>
                
                <h2 className="font-serif text-2xl md:text-4xl text-gold-950 font-bold tracking-wide mb-6">
                  Mangala Swagatham
                </h2>
                
                <p className="text-sm md:text-base text-gold-800 leading-relaxed font-sans max-w-2xl font-light mb-4">
                  Welcome to our virtual wedding portal! Our families are deeply blessed to have you in our lives. With the scent of sacred camphor and dynamic traditional rhythms in the air, we are stepping into our future together. 
                </p>
                
                <p className="text-xs md:text-sm text-gold-700/90 leading-relaxed italic font-serif max-w-xl">
                  "We invite you to witness our wedding film brought to life, explore our celebration schedule, browse through captured moments, and bless our marriage covenant as our esteemed honored guest."
                </p>
              </div>
            </TiltCard>
          </div>
        </section>

        {/* 3. OUR STORY TIMELINE */}
        <section id="story" className="py-24 px-6 max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Visual Frame wrapper with custom parallax */}
            <div className="lg:col-span-6 scroll-reveal opacity-0 translate-y-8 transition-all duration-1000 ease-out">
              <div className="relative group p-3 bg-gradient-to-tr from-gold-200 via-gold-100 to-gold-200 border border-gold-400/30 rounded-2xl shadow-2xl max-w-md mx-auto">
                <div className="relative overflow-hidden rounded-xl h-[480px]">
                  {/* Subtle silk zari mesh overlay */}
                  <div className="absolute inset-4 border border-gold-400/20 pointer-events-none z-10" />
                  
                  <img 
                    src={VENUE_DETAILS.coupleStoryPhoto} 
                    alt="Aria and Arjun portrait" 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover select-none filter sepia-[0.12] brightness-[0.93] transition-transform duration-1000 ease-out group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  
                  {/* Miniature description tag inside portrait */}
                  <div className="absolute bottom-6 left-6 right-6 text-left text-white z-10">
                    <p className="text-[10px] font-sans tracking-widest uppercase font-semibold text-gold-200">Our Sacred Start</p>
                    <p className="text-lg font-serif">Aria &amp; Arjun</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Timeless timeline transcription card */}
            <div className="lg:col-span-6 scroll-reveal opacity-0 translate-y-8 transition-all duration-1000 ease-out text-left">
              <TiltCard className="w-full">
                <div className="py-10 px-6 md:px-10 flex flex-col">
                  <span className="text-[10px] tracking-widest uppercase font-bold text-gold-600 mb-2 font-sans flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-gold-500 animate-pulse" /> From First Meet to Tying Hearts
                  </span>
                  
                  <h2 className="font-serif text-2xl md:text-4xl text-gold-950 font-bold tracking-wide mb-6">
                    Our Story
                  </h2>

                  <div className="space-y-6 text-sm text-gold-800 leading-relaxed font-sans font-light">
                    <p>
                      It started with a mutual admiration for historic art, architecture and traditional south Indian coffees during a rainy afternoon in Bangalore. What blossomed from a simple gallery exchange into late night phone calls and laughter, quickly became a profound coordinate in our destinies.
                    </p>
                    <p>
                      Through coastal climbs in Kerala, shared classical recitals, and quiet temple visits in Kanchipuram, we realized that every landscape, song, and silence was infinitely richer when navigated as one. Under a soft morning spring sky, Arjun asked the question that set our future in motion.
                    </p>
                    <p>
                      Today, we stand in Udaipur — a majestic City of Lakes — to unite our families and histories. We look forward to sealing our vows under the traditional canopy of fragrant flowers.
                    </p>
                  </div>

                  <div className="mt-8 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full border border-gold-300 flex items-center justify-center text-gold-600 bg-gold-50/20">
                      <Heart className="w-4 h-4 text-gold-500 fill-gold-500/20" />
                    </div>
                    <div>
                      <p className="text-[11px] font-sans uppercase tracking-wider font-semibold text-gold-700">Tying the Mangalsutra</p>
                      <p className="text-xs text-gold-800">December 13, 2024</p>
                    </div>
                  </div>
                </div>
              </TiltCard>
            </div>

          </div>
        </section>

        {/* 4. WEDDING EVENTS SCHEDULE */}
        <section id="events" className="py-24 px-6 max-w-6xl mx-auto text-center">
          <div className="scroll-reveal opacity-0 translate-y-8 transition-all duration-1000 ease-out mb-12">
            <h2 className="font-serif text-3xl md:text-5xl text-gold-900 font-bold tracking-wide">
              The Celebration Schedule
            </h2>
            <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-gold-500 to-transparent mx-auto my-4" />
            <p className="text-xs md:text-sm font-sans uppercase tracking-[0.2em] text-gold-600 font-semibold max-w-md mx-auto">
              Please Join Us For These Auspicious Ceremonies
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {WEDDING_EVENTS.map((event, index) => (
              <div 
                key={event.id}
                className="scroll-reveal opacity-0 translate-y-8 transition-all duration-[800ms] cubic-bezier(0.16, 1, 0.3, 1) ease-out"
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <TiltCard 
                  className={`h-full flex flex-col justify-between ${
                    event.id === 'wedding' ? 'border-2 border-gold-500 scale-[1.01] bg-gold-50/40 relative' : ''
                  }`}
                >
                  {/* Distinct card header indicator for active muhurtham */}
                  {event.id === 'wedding' && (
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[#0c0a06] border border-gold-400 px-3.5 py-1 text-white text-[9px] uppercase font-bold tracking-widest rounded-full shadow-lg flex items-center gap-1">
                      <Sparkles className="w-2.5 h-2.5 text-gold-400 animate-pulse" /> Auspicious Muhurtham
                    </div>
                  )}

                  <div className="flex flex-col text-left py-2">
                    {/* Event header metadata */}
                    <div className="flex items-center justify-between mb-4 mt-2">
                      <span className="text-[10px] font-sans font-bold uppercase text-gold-600 tracking-wider flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-gold-400" /> {event.time}
                      </span>
                      <div className="w-8 h-8 rounded-full border border-gold-250 flex items-center justify-center text-gold-600 bg-gold-200/20">
                        {event.iconName === 'Flower' && <Flower className="w-3.5 h-3.5" />}
                        {event.iconName === 'Music' && <Music className="w-3.5 h-3.5" />}
                        {event.iconName === 'Heart' && <Heart className="w-3.5 h-3.5 fill-gold-600" />}
                        {event.iconName === 'Sparkles' && <Sparkles className="w-3.5 h-3.5" />}
                      </div>
                    </div>

                    <h3 className="font-serif text-lg font-bold text-gold-950 mb-1">{event.title}</h3>
                    <p className="text-[11px] font-sans uppercase font-semibold text-gold-600 mb-3">{event.date}</p>
                    
                    <p className="text-xs font-serif italic text-gold-850/80 mb-3 flex items-start gap-1">
                      <MapPin className="w-3.5 h-3.5 text-gold-400 flex-shrink-0 mt-0.5" />
                      <span>{event.venueName}</span>
                    </p>
                    
                    <p className="text-xs text-gold-900/70 font-sans leading-relaxed font-light mb-6">
                      {event.description}
                    </p>
                  </div>

                  <div className="border-t border-gold-300 pt-3 text-left">
                    <p className="text-[9px] uppercase tracking-wider font-semibold text-gold-700 font-sans">
                      Attire Code: <span className="text-gold-950 font-bold">{event.attire}</span>
                    </p>
                  </div>
                </TiltCard>
              </div>
            ))}
          </div>
        </section>

        {/* 5. DESTINATION VENUE */}
        <section id="venue" className="py-24 px-6 max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column - Gilded details and venue photo array */}
            <div className="lg:col-span-6 scroll-reveal opacity-0 translate-y-8 transition-all duration-1000 ease-out text-left order-2 lg:order-1">
              <TiltCard className="w-full">
                <div className="py-10 px-6 lg:px-10 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] tracking-widest uppercase font-bold text-gold-600 mb-2 font-sans flex items-center gap-1.5">
                      <Compass className="w-3.5 h-3.5 text-gold-500 animate-spin" style={{ animationDuration: '6s' }} /> Royal Palace Sanctuary
                    </span>
                    
                    <h2 className="font-serif text-2xl md:text-3xl text-gold-910 font-bold tracking-wide mb-4">
                      {VENUE_DETAILS.name}
                    </h2>
                    
                    <p className="text-xs text-gold-700 uppercase font-bold font-sans tracking-widest mb-4 flex items-start gap-1 pb-3 border-b border-gold-200">
                      <MapPin className="w-3.5 h-3.5 text-gold-600 flex-shrink-0" />
                      {VENUE_DETAILS.address}
                    </p>

                    <p className="text-xs md:text-sm text-gold-800 leading-relaxed font-sans font-light italic mb-8">
                      {VENUE_DETAILS.description}
                    </p>
                  </div>

                  {/* Dual picture showcase framed natively */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="relative group p-1 bg-gold-100 border border-gold-300/40 rounded-lg overflow-hidden flex flex-col">
                      <div className="overflow-hidden rounded h-28 relative">
                        <img 
                          src={VENUE_DETAILS.photo1} 
                          alt="The Oberoi Udaivilas courtyard" 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover filter brightness-[0.9] saturate-[1.05] transition-transform duration-500 group-hover:scale-105" 
                        />
                      </div>
                      <span className="text-[9px] uppercase font-bold text-gold-600 tracking-wider mt-1.5 text-center block">Reflection Arch</span>
                    </div>

                    <div className="relative group p-1 bg-gold-100 border border-gold-300/40 rounded-lg overflow-hidden flex flex-col">
                      <div className="overflow-hidden rounded h-28 relative">
                        <img 
                          src={VENUE_DETAILS.photo2} 
                          alt="Palace table preparations" 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover filter brightness-[0.9] saturate-[1.05] transition-transform duration-500 group-hover:scale-105" 
                        />
                      </div>
                      <span className="text-[9px] uppercase font-bold text-gold-600 tracking-wider mt-1.5 text-center block">Imperial Table</span>
                    </div>
                  </div>
                </div>
              </TiltCard>
            </div>

            {/* Right Column - Map viewport with custom copper overlay borders */}
            <div className="lg:col-span-6 scroll-reveal opacity-0 translate-y-8 transition-all duration-1000 ease-out order-1 lg:order-2">
              <div className="relative p-3 bg-gradient-to-tr from-gold-300 via-gold-100 to-gold-300 border border-gold-400/40 rounded-2xl shadow-2xl h-[460px] max-w-md lg:max-w-none mx-auto">
                <div className="absolute inset-4 border border-gold-400/20 pointer-events-none z-10" />
                <div className="w-full h-full rounded-xl overflow-hidden relative">
                  <iframe 
                    title="The Oberoi Udaivilas venue map location"
                    src={VENUE_DETAILS.mapUrl} 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    allowFullScreen={true} 
                    loading="lazy" 
                    referrerPolicy="no-referrer"
                    className="w-full h-full select-none filter sepia-[0.16] contrast-[0.96] brightness-[0.88] shadow-inner"
                  />
                  <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur border border-gold-300 px-3.5 py-1.5 rounded-lg text-left shadow-md flex items-center gap-1">
                    <span className="text-[10px] font-sans font-bold text-gold-800 uppercase tracking-widest flex items-center gap-1">
                      Lake Pichola Sanctuary <ExternalLink className="w-3 h-3 text-gold-600" />
                    </span>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* 6. PHOTO GALLERY (3D BENTO GRID) */}
        <section id="gallery" className="py-24 px-6 max-w-6xl mx-auto text-center">
          <div className="scroll-reveal opacity-0 translate-y-8 transition-all duration-1000 ease-out mb-12">
            <h2 className="font-serif text-3xl md:text-5xl text-gold-900 font-bold tracking-wide">
              Shared Moments
            </h2>
            <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-gold-500 to-transparent mx-auto my-4" />
            <p className="text-xs md:text-sm font-sans uppercase tracking-[0.2em] text-gold-600 font-semibold max-w-md mx-auto">
              A Glimpse into Our Sacred Journey
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 md:grid-rows-2 gap-6 min-h-[640px]">
            {GALLERY_MOMENTS.map((moment, index) => {
              // Apply dynamic layered scroll offsets
              const layeredTranslateY = scrollY * moment.depth * 0.18;

              return (
                <div
                  key={moment.id}
                  onClick={() => setLightboxIndex(index)}
                  className={`relative group rounded-xl overflow-hidden cursor-pointer select-none border border-gold-300/35 shadow-lg bg-gold-200/10 ${moment.gridSpan} scroll-reveal opacity-0 translate-y-8 transition-all duration-[900ms] cubic-bezier(0.16, 1, 0.3, 1) ease-out`}
                  style={{ 
                    transitionDelay: `${index * 120}ms`,
                    transform: `translateY(${layeredTranslateY}px)`
                  }}
                >
                  <div className="relative w-full h-full overflow-hidden">
                    {/* Symmetrical zari vector outline inside box */}
                    <div className="absolute inset-3 border border-gold-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10 pointer-events-none" />

                    <img 
                      src={moment.imageUrl} 
                      alt={moment.title} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover filter sepia-[0.11] brightness-[0.88] group-hover:brightness-[0.94] group-hover:sepia-0 group-hover:scale-105 transition-all duration-700 ease-out"
                    />
                    
                    {/* Floating label caption that slides in */}
                    <div className="absolute inset-x-0 bottom-0 py-6 px-5 bg-gradient-to-t from-black/85 via-black/40 to-transparent text-left translate-y-3 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500 z-15">
                      <p className="text-[10px] font-sans font-bold uppercase tracking-widest text-gold-300 mb-0.5">{moment.subtitle}</p>
                      <h4 className="font-serif text-base text-white font-medium">{moment.title}</h4>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* 7. SECURE RSVP DECK */}
        <section id="rsvp" className="py-24 px-6 max-w-6xl mx-auto">
          <div className="scroll-reveal opacity-0 translate-y-8 transition-all duration-1000 ease-out">
            <TiltCard scale={1.0} className="max-w-6xl w-full mx-auto">
              <div className="py-12 px-6 lg:px-12">
                <RsvpForm />
              </div>
            </TiltCard>
          </div>
        </section>

      </main>

      {/* LUXURIOUS TIMELESS SIGNATURE FOOTER */}
      <footer className="relative z-10 bg-[#fffdf7] border-t border-gold-300 py-16 px-6">
        <div className="max-w-5xl mx-auto flex flex-col items-center text-center">
          
          <span className="font-cinzel text-xl md:text-3xl font-bold tracking-widest text-gold-950">
            {BRIDE_NAME} <span className="text-gold-500 font-serif font-light">&amp;</span> {GROOM_NAME}
          </span>
          <div className="w-[100px] h-[1px] bg-gradient-to-r from-transparent via-gold-400 to-transparent my-6" />

          <p className="text-sm text-gold-900/80 max-w-md font-sans leading-relaxed font-light italic mb-8">
            "Your presence and blessings are our greatest wedding treasure. Thank you for celebrating this timeless filmic journey of ours."
          </p>

          <div className="flex flex-wrap items-center justify-center gap-8 mb-8">
            {[
              { id: 'story', label: 'Our Story' },
              { id: 'events', label: 'Schedule' },
              { id: 'venue', label: 'Palace Destination' },
              { id: 'gallery', label: 'Gallery Moments' },
              { id: 'rsvp', label: 'Invitation Response' }
            ].map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="text-[10px] uppercase font-bold tracking-widest text-gold-700 hover:text-gold-500 cursor-pointer focus:outline-none transition-colors"
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="w-10 h-10 rounded-full border border-gold-300 flex items-center justify-center text-gold-600 mb-6 animate-pulse">
            <Heart className="w-4 h-4 text-gold-500 fill-gold-500" />
          </div>

          <p className="text-[10px] uppercase font-bold text-gold-600 tracking-wider mb-1">
            With Eternal Love, Aria and Arjun
          </p>
          <p className="text-[9px] text-gold-700/60 font-sans tracking-wide">
            Auspicious Ceremonies • Udaipur 2024
          </p>
        </div>
      </footer>

      {/* LIGHTBOX MODAL EXPANSIONS (GALLERY IMAGE ZOOM VIEW) */}
      {lightboxIndex !== null && (
        <div 
          onClick={() => setLightboxIndex(null)}
          className="fixed inset-0 z-100 bg-black/95 backdrop-blur-md flex items-center justify-center py-6 px-6 cursor-zoom-out animate-fade-in"
        >
          {/* Symmetrical golden grid borders under lightbox frame */}
          <div className="absolute inset-8 border border-gold-450/10 pointer-events-none z-10" />

          {/* Symmetrical modal header control */}
          <button 
            onClick={() => setLightboxIndex(null)}
            className="absolute top-6 right-6 text-white/70 hover:text-white p-2.5 bg-white/5 border border-white/10 rounded-full cursor-pointer hover:bg-white/10 transition-colors z-20"
            aria-label="Close Lightbox"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Back image button */}
          <button
            onClick={prevImage}
            className="absolute left-6 text-white/70 hover:text-white p-3.5 bg-white/5 border border-white/10 rounded-full cursor-pointer hover:bg-white/10 transition-colors z-20"
            aria-label="Previous Image"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* Active Image frame wrapper */}
          <div 
            onClick={(e) => e.stopPropagation()}
            className="max-w-4xl max-h-[80vh] w-full relative flex flex-col items-center bg-gray-950 p-3 rounded-lg border border-gold-500/20 shadow-2xl cursor-default animate-fade-in"
          >
            <div className="relative w-full h-[60vh] overflow-hidden rounded">
              <img
                src={GALLERY_MOMENTS[lightboxIndex].imageUrl}
                alt={GALLERY_MOMENTS[lightboxIndex].title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter brightness-[0.95]"
              />
            </div>
            
            <div className="text-center py-4 bg-gray-950/70 border-t border-gold-500/10 w-full mt-2">
              <span className="text-[10px] font-sans font-bold uppercase tracking-widest text-gold-400">
                {GALLERY_MOMENTS[lightboxIndex].subtitle}
              </span>
              <h4 className="font-serif text-lg text-white font-medium mt-0.5">
                {GALLERY_MOMENTS[lightboxIndex].title}
              </h4>
            </div>
          </div>

          {/* Next image button */}
          <button
            onClick={nextImage}
            className="absolute right-6 text-white/70 hover:text-white p-3.5 bg-white/5 border border-white/10 rounded-full cursor-pointer hover:bg-white/10 transition-colors z-20"
            aria-label="Next Image"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}

    </div>
  );
}

