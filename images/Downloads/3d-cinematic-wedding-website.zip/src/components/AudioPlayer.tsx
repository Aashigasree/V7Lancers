/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, Music, ChevronLeft, ChevronRight } from 'lucide-react';

interface Track {
  title: string;
  artist: string;
  url: string;
}

const TRADITIONAL_TRACKS: Track[] = [
  {
    title: "Celestial Sitar",
    artist: "Carnatic String Orchestrations",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
  },
  {
    title: "Lotus Flute",
    artist: "Divine Bamboo Raga",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
  }
];

export default function AudioPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [volume, setVolume] = useState(0.4);
  const [showPanel, setShowPanel] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const track = TRADITIONAL_TRACKS[currentTrackIndex];

  useEffect(() => {
    // Initialise audio instance
    const audio = new Audio(track.url);
    audio.loop = true;
    audio.volume = volume;
    audioRef.current = audio;

    // Handle play state on track change if previously playing
    if (isPlaying) {
      audio.play().catch(() => {
        setIsPlaying(false);
      });
    }

    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, [currentTrackIndex]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch(err => {
          console.warn("Audio playback blocked by platform permissions. Click interaction is required first.", err);
          // Let's retry
          setIsPlaying(false);
        });
    }
  };

  const nextTrack = () => {
    setCurrentTrackIndex((prev) => (prev + 1) % TRADITIONAL_TRACKS.length);
  };

  const prevTrack = () => {
    setCurrentTrackIndex((prev) => (prev - 1 + TRADITIONAL_TRACKS.length) % TRADITIONAL_TRACKS.length);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3">
      {/* Mini Controls Card on Hover/Toggle */}
      {showPanel && (
        <div 
          className="silk-glass rounded-full py-2 px-5 flex items-center gap-4 transition-all duration-300 transform scale-100 origin-right border border-gold-300 shadow-xl"
          style={{ animation: 'fade-in 0.3s ease-out' }}
        >
          <div className="text-left select-none">
            <p className="text-[10px] uppercase font-semibold text-gold-600 tracking-widest">Ambient Film Music</p>
            <p className="text-xs font-serif font-semibold text-gold-900 truncate max-w-[120px]">{track.title}</p>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={prevTrack} 
              className="text-gold-700 hover:text-gold-500 transition-colors p-1"
              aria-label="Previous track"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={nextTrack} 
              className="text-gold-700 hover:text-gold-500 transition-colors p-1"
              aria-label="Next track"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            
            <div className="flex items-center gap-1.5 ml-1">
              <span className="text-gold-700 select-none">
                {isPlaying ? <Volume2 className="w-3.5 h-3.5 animate-pulse" /> : <VolumeX className="w-3.5 h-3.5" />}
              </span>
              <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.05" 
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-12 h-1 bg-gold-200 rounded-lg appearance-none cursor-pointer accent-gold-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* Floating Main Audio Button */}
      <button
        onClick={togglePlay}
        onMouseEnter={() => setShowPanel(true)}
        onMouseLeave={() => {
          setTimeout(() => {
            // we will let it stay open or just hide gracefully
          }, 1500);
        }}
        onDoubleClick={() => setShowPanel(!showPanel)}
        className="w-12 h-12 rounded-full flex items-center justify-center cursor-pointer relative shadow-xl focus:outline-none transition-all duration-300 bg-gold-100 hover:bg-gold-200 hover:scale-105 border border-gold-400 group"
        aria-label="Toggle wedding music"
      >
        {/* Pulsing ring during playback */}
        {isPlaying && (
          <span className="absolute inset-0 rounded-full border border-gold-400 animate-ping opacity-60" />
        )}
        
        {isPlaying ? (
          <Music className="w-5 h-5 text-gold-700 animate-spin" style={{ animationDuration: '8s' }} />
        ) : (
          <VolumeX className="w-5 h-5 text-gold-600 transition-transform group-hover:scale-110" />
        )}
      </button>

      {/* Visual Indicator of Hover Control */}
      {!showPanel && (
        <span className="absolute -top-1 -left-1 flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-gold-500"></span>
        </span>
      )}
    </div>
  );
}
