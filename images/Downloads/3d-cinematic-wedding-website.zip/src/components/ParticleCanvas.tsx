/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';

interface ParticleCanvasProps {
  scrollY: number;
}

export default function ParticleCanvas({ scrollY }: ParticleCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.targetX = e.clientX;
      mouseRef.current.targetY = e.clientY;
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = window.innerWidth;
    let height = window.innerHeight;

    const handleResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();

    // 3D parameters
    const FOCAL_LENGTH = 350;

    // Golden dust particles
    class GoldDust {
      x: number = 0;
      y: number = 0;
      size: number = 0;
      vy: number = 0;
      vx: number = 0;
      opacity: number = 0;
      twinklePhase: number = 0;
      twinkleSpeed: number = 0;

      constructor() {
        this.reset();
        this.y = Math.random() * height; // initially scatter
      }

      reset() {
        this.x = Math.random() * width;
        this.y = height + Math.random() * 50;
        this.size = Math.random() * 2 + 0.8;
        this.vy = -(Math.random() * 0.7 + 0.3);
        this.vx = Math.random() * 0.5 - 0.25;
        this.opacity = Math.random() * 0.45 + 0.15;
        this.twinklePhase = Math.random() * Math.PI;
        this.twinkleSpeed = Math.random() * 0.02 + 0.01;
      }

      update(scrollDelta: number, mouseX: number) {
        // Accelerate or drift slightly with scroll
        const scrollEffect = scrollDelta * 0.15;
        this.y += this.vy - scrollEffect;
        
        // Gentle wind effect based on mouse location
        const mouseRatio = (mouseX / width) - 0.5;
        this.x += this.vx + mouseRatio * 0.4 + Math.sin(this.y * 0.01) * 0.15;
        this.twinklePhase += this.twinkleSpeed;

        if (this.y < -15 || this.x < -15 || this.x > width + 15) {
          this.reset();
        }
      }

      draw(c: CanvasRenderingContext2D) {
        const currentOpacity = this.opacity * (0.65 + 0.35 * Math.sin(this.twinklePhase));
        c.save();
        c.beginPath();
        c.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        
        // Golden glow colour
        c.fillStyle = `rgba(212, 175, 55, ${currentOpacity * 1.2})`;
        c.shadowColor = '#d4af37';
        c.shadowBlur = 3;
        c.fill();
        c.restore();
      }
    }

    // Jasmine Flower Petal (traditional 'malli pookkal')
    class JasminePetal {
      x: number = 0;
      y: number = 0;
      z: number = 0;
      size: number = 0;
      vy: number = 0;
      vx: number = 0;
      vz: number = 0;
      rotX: number = 0;
      rotY: number = 0;
      rotZ: number = 0;
      vRotX: number = 0;
      vRotY: number = 0;
      vRotZ: number = 0;
      swayFrec: number = 0;
      swayAmp: number = 0;

      constructor() {
        this.reset();
        this.y = Math.random() * height * -1.5; // scatter up high
      }

      reset() {
        this.x = (Math.random() - 0.5) * width * 1.8;
        this.y = -80 - Math.random() * 400;
        this.z = Math.random() * 700 + 40; // depth

        this.size = Math.random() * 11 + 6;
        this.vy = Math.random() * 1.3 + 0.8;
        this.vx = Math.random() * 0.6 - 0.3;
        this.vz = Math.random() * 0.2 - 0.1;

        this.rotX = Math.random() * Math.PI * 2;
        this.rotY = Math.random() * Math.PI * 2;
        this.rotZ = Math.random() * Math.PI * 2;

        this.vRotX = Math.random() * 0.02 - 0.01;
        this.vRotY = Math.random() * 0.02 - 0.01;
        this.vRotZ = Math.random() * 0.025 - 0.012;

        this.swayFrec = Math.random() * 0.006 + 0.003;
        this.swayAmp = Math.random() * 0.7 + 0.3;
      }

      update(scrollDelta: number, mouseX: number) {
        // Falling speed is reactive to scrolling
        const scrollEffect = scrollDelta * 0.22;
        this.y += this.vy + scrollEffect;
        
        const mouseRatio = (mouseX / width) - 0.5;
        this.x += this.vx + mouseRatio * 0.8 + Math.sin(this.y * this.swayFrec) * this.swayAmp;
        this.z += this.vz; // moves in 3D depth towards/away from screen

        this.rotX += this.vRotX;
        this.rotY += this.vRotY;
        this.rotZ += this.vRotZ;

        // Project onto 2D screen coordinate
        const scale = FOCAL_LENGTH / (FOCAL_LENGTH + this.z);
        const projX = (width / 2) + this.x * scale;
        const projY = (height / 2) + this.y * scale;

        // Reset if we go out of bounds
        if (
          projY > height + 80 || 
          projX < -150 || 
          projX > width + 150 || 
          this.z < -FOCAL_LENGTH || 
          this.z > 1200
        ) {
          this.reset();
        }
      }

      draw(c: CanvasRenderingContext2D) {
        const scale = FOCAL_LENGTH / (FOCAL_LENGTH + this.z);
        const projX = (width / 2) + this.x * scale;
        const projY = (height / 2) + this.y * scale;
        const finalSize = this.size * scale;

        // Clip out negative scale or out of screen points
        if (scale <= 0 || projY < -100 || projY > height + 100) return;

        c.save();
        c.translate(projX, projY);
        c.rotate(this.rotZ);
        c.scale(Math.cos(this.rotX), Math.sin(this.rotY));

        // Organic soft curved petal (jasmine teardrop)
        c.beginPath();
        c.moveTo(0, -finalSize);
        c.quadraticCurveTo(finalSize * 0.75, -finalSize * 0.25, 0, finalSize);
        c.quadraticCurveTo(-finalSize * 0.75, -finalSize * 0.25, 0, -finalSize);
        c.closePath();

        // Creamy ivory, sunset blush gradient
        const gradient = c.createLinearGradient(0, finalSize, 0, -finalSize);
        gradient.addColorStop(0, 'rgba(255, 253, 245, 0.95)'); // soft ivory base
        gradient.addColorStop(0.3, 'rgba(255, 255, 255, 0.98)'); // pure white middle
        gradient.addColorStop(0.85, 'rgba(253, 240, 241, 0.95)'); // very subtle pink trace
        gradient.addColorStop(1, 'rgba(250, 218, 221, 0.85)'); // blush pink tip

        c.fillStyle = gradient;

        // Calculate distance blur (Camera depth-of-field)
        // Close to camera (z is low) or far (z is high) get slight blurs, z=150 is sharp focus
        const focusDistance = Math.abs(this.z - 150);
        if (focusDistance > 300) {
          c.shadowColor = 'rgba(255, 253, 245, 0.45)';
          c.shadowBlur = Math.min(10, focusDistance / 50);
        } else {
          c.shadowColor = 'rgba(212, 175, 55, 0.18)';
          c.shadowBlur = 2;
        }

        c.fill();
        c.restore();
      }
    }

    // Soft volumetric bokeh warm spheres
    class BokehBall {
      x: number = 0;
      y: number = 0;
      radius: number = 0;
      vy: number = 0;
      vx: number = 0;
      baseOpacity: number = 0;
      colorIndex: number = 0;

      constructor() {
        this.reset();
        this.y = Math.random() * height;
      }

      reset() {
        this.x = Math.random() * width;
        this.y = height + Math.random() * 150;
        this.radius = Math.random() * 55 + 25;
        this.vy = -(Math.random() * 0.25 + 0.1);
        this.vx = Math.random() * 0.2 - 0.1;
        this.baseOpacity = Math.random() * 0.05 + 0.012; // super subtle
        this.colorIndex = Math.random() > 0.5 ? 1 : 0; // gold or pink
      }

      update(scrollDelta: number) {
        const scrollEffect = scrollDelta * 0.1;
        this.y += this.vy - scrollEffect;
        this.x += this.vx;

        if (this.y < -this.radius * 2) {
          this.reset();
        }
      }

      draw(c: CanvasRenderingContext2D) {
        c.save();
        c.beginPath();
        c.arc(this.x, this.y, this.radius, 0, Math.PI * 2);

        const radialGradient = c.createRadialGradient(
          this.x, this.y, 0, 
          this.x, this.y, this.radius
        );

        if (this.colorIndex === 1) {
          // Warm Gold Bokeh
          radialGradient.addColorStop(0, `rgba(212, 175, 55, ${this.baseOpacity})`);
          radialGradient.addColorStop(0.5, `rgba(234, 210, 151, ${this.baseOpacity * 0.4})`);
          radialGradient.addColorStop(1, 'rgba(212, 175, 55, 0)');
        } else {
          // Blush Pink Bokeh
          radialGradient.addColorStop(0, `rgba(250, 218, 221, ${this.baseOpacity * 1.5})`);
          radialGradient.addColorStop(0.6, `rgba(240, 143, 151, ${this.baseOpacity * 0.5})`);
          radialGradient.addColorStop(1, 'rgba(250, 218, 221, 0)');
        }

        c.fillStyle = radialGradient;
        c.fill();
        c.restore();
      }
    }

    // Allocate pool
    const dustArray: GoldDust[] = Array.from({ length: 45 }, () => new GoldDust());
    const petalArray: JasminePetal[] = Array.from({ length: 24 }, () => new JasminePetal());
    const bokehArray: BokehBall[] = Array.from({ length: 7 }, () => new BokehBall());

    let lastScrollY = scrollY;

    // Fluid loop
    const renderLoop = () => {
      // Calculate scroll difference
      const currentScrollY = window.scrollY;
      const scrollDelta = currentScrollY - lastScrollY;
      lastScrollY = currentScrollY;

      // Smooth mouse coordinates interpolation (lerp)
      const mouse = mouseRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.08;
      mouse.y += (mouse.targetY - mouse.y) * 0.08;

      ctx.clearRect(0, 0, width, height);

      // Render order: Bokeh -> Dust -> Petals (Back to front layering for 3D depth)
      
      // 1. Bokeh
      bokehArray.forEach(b => {
        b.update(scrollDelta);
        b.draw(ctx);
      });

      // 2. Gold Dust
      dustArray.forEach(d => {
        d.update(scrollDelta, mouse.x);
        d.draw(ctx);
      });

      // 3. Jasmine Petals
      petalArray.forEach(p => {
        p.update(scrollDelta, mouse.x);
        p.draw(ctx);
      });

      animationFrameId = requestAnimationFrame(renderLoop);
    };

    renderLoop();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none z-20"
      style={{ willChange: 'transform' }}
    />
  );
}
