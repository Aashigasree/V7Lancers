/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GuestRSVP } from '../types';
import { Check, Send, Users, HeartHandshake, Smile } from 'lucide-react';

export default function RsvpForm() {
  const [name, setName] = useState('');
  const [attending, setAttending] = useState<string>('accept');
  const [guestsCount, setGuestsCount] = useState<number>(1);
  const [dietaryNotes, setDietaryNotes] = useState('');
  const [greeting, setGreeting] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [rsvpList, setRsvpList] = useState<GuestRSVP[]>([]);

  // Load RSVPs from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('wedding_rsvp_list');
      if (saved) {
        setRsvpList(JSON.parse(saved));
      } else {
        // Mock seed data so sheet is never empty
        const initialMock: GuestRSVP[] = [
          {
            id: '1',
            name: 'Ramesh & Meera Krishnan',
            attending: true,
            guestsCount: 2,
            dietaryNotes: 'Traditional South Indian Vegetarian',
            createdAt: new Date(Date.now() - 3600000 * 24).toISOString()
          },
          {
            id: '2',
            name: 'Ananya Iyer',
            attending: true,
            guestsCount: 1,
            dietaryNotes: 'No allergies',
            createdAt: new Date(Date.now() - 3600000 * 12).toISOString()
          }
        ];
        localStorage.setItem('wedding_rsvp_list', JSON.stringify(initialMock));
        setRsvpList(initialMock);
      }
    } catch (e) {
      console.warn("Could not load RSVPs:", e);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newRsvp: GuestRSVP = {
      id: Math.random().toString(36).substring(2, 9),
      name: name.trim(),
      attending: attending === 'accept',
      guestsCount: attending === 'accept' ? guestsCount : 0,
      dietaryNotes: (dietaryNotes.trim() ? dietaryNotes.trim() : '') + (greeting.trim() ? ` | Greeting: ${greeting.trim()}` : ''),
      createdAt: new Date().toISOString()
    };

    const updatedList = [newRsvp, ...rsvpList];
    setRsvpList(updatedList);
    try {
      localStorage.setItem('wedding_rsvp_list', JSON.stringify(updatedList));
    } catch (err) {
      console.error(err);
    }

    setSubmitted(true);
    setTimeout(() => {
      // Auto reset form entries
      setName('');
      setDietaryNotes('');
      setGreeting('');
      setGuestsCount(1);
    }, 1000);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
      {/* RSVP Form Section */}
      <div className="md:col-span-7">
        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="text-center md:text-left">
              <p className="text-xs uppercase font-semibold text-gold-600 tracking-widest mb-1 font-sans">Traditional Response</p>
              <h3 className="text-2xl font-serif font-semibold text-gold-900">Are You Joining Our Celebration?</h3>
              <p className="text-sm text-gold-800/80 mt-1">Please respond by November 1st, 2024 to help us custom curate our arrangements.</p>
            </div>

            <div className="space-y-4 text-left">
              {/* Guest Name input */}
              <div className="flex flex-col">
                <label className="text-xs uppercase font-serif font-semibold text-gold-700 tracking-wider mb-2">
                  Your Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Aditi & Raghav Sridhar"
                  className="w-full bg-gold-100/30 border-b border-gold-400 placeholder-gold-800/50 py-2.5 px-1 font-sans text-gold-900 text-sm focus:outline-none focus:border-gold-700 focus:bg-gold-200/20 transition-all rounded-t-sm"
                />
              </div>

              {/* Attendance Radios */}
              <div className="grid grid-cols-2 gap-4 pt-2">
                <label 
                  onClick={() => setAttending('accept')}
                  className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer select-none transition-all ${
                    attending === 'accept' 
                      ? 'border-gold-500 bg-gold-100/40 text-gold-900 shadow-sm' 
                      : 'border-gold-300 text-gold-800 hover:border-gold-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <HeartHandshake className="w-4 h-4 text-gold-600" />
                    <span className="text-xs font-semibold uppercase tracking-wider font-sans">Joyfully Accepts</span>
                  </div>
                  <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${attending === 'accept' ? 'border-gold-600' : 'border-gold-400'}`}>
                    {attending === 'accept' && <div className="w-1.5 h-1.5 rounded-full bg-gold-600" />}
                  </div>
                </label>

                <label 
                  onClick={() => setAttending('decline')}
                  className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer select-none transition-all ${
                    attending === 'decline' 
                      ? 'border-gold-500 bg-gold-100/40 text-gold-900 shadow-sm' 
                      : 'border-gold-300 text-gold-800 hover:border-gold-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gold-600" />
                    <span className="text-xs font-semibold uppercase tracking-wider font-sans">Regretfully Declines</span>
                  </div>
                  <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${attending === 'decline' ? 'border-gold-600' : 'border-gold-400'}`}>
                    {attending === 'decline' && <div className="w-1.5 h-1.5 rounded-full bg-gold-600" />}
                  </div>
                </label>
              </div>

              {/* Guests Selector (only show if accepting) */}
              {attending === 'accept' && (
                <div className="flex flex-col animate-fade-in">
                  <label className="text-xs uppercase font-serif font-semibold text-gold-700 tracking-wider mb-2">
                    Number of Guests Attending
                  </label>
                  <div className="flex items-center gap-3">
                    {[1, 2, 3, 4, 5].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setGuestsCount(num)}
                        className={`w-9 h-9 rounded-full border flex items-center justify-center text-xs font-semibold transition-all ${
                          guestsCount === num 
                            ? 'bg-gold-500 border-gold-500 text-white shadow-md' 
                            : 'border-gold-300 text-gold-800 hover:border-gold-400'
                        }`}
                      >
                        {num}
                      </button>
                    ))}
                    <span className="text-xs text-gold-800/70 font-sans ml-1 italic">(including packages & children)</span>
                  </div>
                </div>
              )}

              {/* Special dietary requirements */}
              <div className="flex flex-col">
                <label className="text-xs uppercase font-serif font-semibold text-gold-700 tracking-wider mb-2">
                  Dietary Preferences / Restrictions
                </label>
                <input
                  type="text"
                  value={dietaryNotes}
                  onChange={(e) => setDietaryNotes(e.target.value)}
                  placeholder="e.g. Vegetarian, nut allergy, vegan, or infant meals"
                  className="w-full bg-gold-100/30 border-b border-gold-400 placeholder-gold-800/50 py-2.5 px-1 font-sans text-gold-900 text-sm focus:outline-none focus:border-gold-700 focus:bg-gold-200/20 transition-all rounded-t-sm"
                />
              </div>

              {/* Warm Blessing Message */}
              <div className="flex flex-col">
                <label className="text-xs uppercase font-serif font-semibold text-gold-700 tracking-wider mb-2">
                  Your Congratulatory Blessing or Greeting
                </label>
                <textarea
                  value={greeting}
                  onChange={(e) => setGreeting(e.target.value)}
                  placeholder="Write a tiny blessing for Aria & Arjun here..."
                  className="w-full bg-gold-100/30 border-b border-gold-400 placeholder-gold-800/50 py-2.5 px-1 font-sans text-gold-900 text-sm focus:outline-none focus:border-gold-700 focus:bg-gold-200/20 transition-all rounded-t-sm h-18 resize-none"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-gold-600 via-gold-500 to-gold-600 text-white font-semibold font-sans uppercase tracking-widest text-xs rounded shadow-lg hover:shadow-xl hover:scale-[1.01] transition-all cursor-pointer flex items-center justify-center gap-2 border border-gold-400/30"
            >
              <Send className="w-3.5 h-3.5" />
              Secure Response
            </button>
          </form>
        ) : (
          <div className="py-12 px-6 text-center space-y-4 animate-fade-in">
            <div className="w-16 h-16 bg-gold-200/50 rounded-full flex items-center justify-center mx-auto text-gold-600 border border-gold-400/40">
              <Check className="w-8 h-8" />
            </div>
            <h4 className="text-2xl font-serif text-gold-900 font-semibold">Response Submitted with Blessing</h4>
            <p className="text-sm text-gold-800 max-w-sm mx-auto leading-relaxed">
              We have safely received and stored your response inside our digital guest registry. Your presence warms our hearts. Thank you for celebrating this auspicious life transition with us!
            </p>
            <button
              onClick={() => setSubmitted(false)}
              className="mt-4 px-6 py-2 border border-gold-500 text-gold-700 hover:bg-gold-100/40 text-xs uppercase font-sans tracking-widest font-semibold rounded transition-all cursor-pointer"
            >
              Update / Submit Another response
            </button>
          </div>
        )}
      </div>

      {/* Live Guest board Panel on the other side */}
      <div className="md:col-span-5 h-full flex flex-col">
        <div className="silk-glass/10 rounded-xl p-4 border border-gold-300 flex flex-col h-[400px]">
          <div className="border-b border-gold-300 pb-3 mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smile className="w-4 h-4 text-gold-600" />
              <p className="text-xs uppercase font-serif font-bold text-gold-800 tracking-wider">Auspicious Blessings</p>
            </div>
            <span className="text-[10px] bg-gold-200 px-2.5 py-0.5 rounded-full text-gold-800 font-semibold font-sans">
              {rsvpList.filter(r => r.attending).length} Attending
            </span>
          </div>

          <div className="flex-grow overflow-y-auto space-y-3.5 pr-2 scrollbar-thin">
            {rsvpList.length > 0 ? (
              rsvpList.map((rsvp) => {
                const parts = rsvp.dietaryNotes.split(' | Greeting: ');
                const cleanDiet = parts[0] || '';
                const cleanGreet = parts[1] || '';

                return (
                  <div key={rsvp.id} className="bg-gold-50/50 rounded p-3 border border-gold-200/50 text-left transition-all hover:bg-gold-50 animate-fade-in">
                    <div className="flex items-start justify-between">
                      <p className="text-xs font-serif font-semibold text-gold-900 truncate pr-2">{rsvp.name}</p>
                      <span className={`text-[9px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded ${
                        rsvp.attending 
                          ? 'bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700' 
                          : 'bg-rose-100 dark:bg-rose-950/40 text-rose-700'
                      }`}>
                        {rsvp.attending ? `Attending (${rsvp.guestsCount})` : 'Declined'}
                      </span>
                    </div>
                    {cleanGreet && (
                      <p className="text-xs italic text-gold-800 font-serif mt-1.5 leading-relaxed">
                        "{cleanGreet}"
                      </p>
                    )}
                    {cleanDiet && cleanDiet !== 'No allergies' && !cleanDiet.startsWith(' | ') && (
                      <p className="text-[10px] text-gold-600/70 font-sans mt-1">
                        Requirements: {cleanDiet}
                      </p>
                    )}
                  </div>
                );
              })
            ) : (
              <p className="text-xs text-gold-800/40 italic py-12">No responses logged yet...</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
