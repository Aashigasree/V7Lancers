/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, MouseEvent } from 'react';

interface TiltCardProps {
  children: React.ReactNode;
  className?: string;
  maxTilt?: number;
  scale?: number;
  dark?: boolean;
}

export default function TiltCard({
  children,
  className = '',
  maxTilt = 7,
  scale = 1.02,
  dark = false
}: TiltCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({
    transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)',
    transition: 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)'
  });
  const [sheenPosition, setSheenPosition] = useState({ x: '50%', y: '50%', opacity: 0 });

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Normalize coordinates from -0.5 to 0.5
    const normX = (x / rect.width) - 0.5;
    const normY = (y / rect.height) - 0.5;

    // Calculate rotation angles
    const rotateX = -normY * maxTilt;
    const rotateY = normX * maxTilt;

    // Apply 3D transform style
    setStyle({
      transform: `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(${scale})`,
      transition: 'transform 0.1s cubic-bezier(0.16, 1, 0.3, 1)'
    });

    // Update reflection sheen position
    setSheenPosition({
      x: `${(x / rect.width) * 100}%`,
      y: `${(y / rect.height) * 100}%`,
      opacity: 0.45
    });
  };

  const handleMouseLeave = () => {
    setStyle({
      transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)',
      transition: 'transform 0.8s cubic-bezier(0.16, 1, 0.3, 1)'
    });

    setSheenPosition(prev => ({
      ...prev,
      opacity: 0
    }));
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={style}
      className={`relative rounded-xl overflow-hidden cursor-pointer preserve-3d select-none ${
        dark ? 'silk-glass-dark' : 'silk-glass'
      } ${className}`}
    >
      {/* Sheen Overlay Layer */}
      <div
        className="absolute inset-0 pointer-events-none mix-blend-overlay transition-opacity duration-500 ease-out z-10"
        style={{
          background: `radial-gradient(circle at ${sheenPosition.x} ${sheenPosition.y}, rgba(255, 253, 245, 0.5) 0%, transparent 60%)`,
          opacity: sheenPosition.opacity
        }}
      />
      
      {/* Traditional Zari Border Pattern */}
      <div className="zari-border h-full flex flex-col justify-between">
        <div className="zari-temple-row-top" />
        <div className="zari-inner-line" />
        <div className="relative z-10 h-full w-full">
          {children}
        </div>
        <div className="zari-temple-row-bottom" />
      </div>
    </div>
  );
}
