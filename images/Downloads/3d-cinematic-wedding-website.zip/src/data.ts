/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeddingEvent, GalleryMoment } from './types';

export const BRIDE_NAME = "Aria";
export const GROOM_NAME = "Arjun";
export const WEDDING_DATE = "December 14th, 2024";
export const WEDDING_LOCATION = "Udaipur, Rajasthan";

export const CELEBRATION_DATES = {
  mehendi: "December 12 • 2:00 PM",
  sangeet: "December 12 • 7:30 PM",
  muhurtham: "December 13 • 4:00 PM",
  reception: "December 14 • 8:00 PM",
};

export const WEDDING_EVENTS: WeddingEvent[] = [
  {
    id: "mehendi",
    title: "Mehendi & High Tea",
    date: "Dec 12th, 2024",
    time: "2:00 PM",
    venueName: "The Garden Terrace & Courtyards",
    description: "A lively Kanchipuram-silk themed afternoon of hand-crafted henna artistry, live sitar-fusion music, organic cold brews, and Rajasthani-South Indian high tea delights.",
    attire: "Festive Brights (Saffron, Sanyas Yellow & Parrot Green Preferred)",
    iconName: "Flower"
  },
  {
    id: "sangeet",
    title: "The Sangeet Night",
    date: "Dec 12th, 2024",
    time: "7:30 PM",
    venueName: "The Mewar Grand Ballroom",
    description: "An evening of imperial dance spectacles, family playback musical performances, custom cocktails inspired by traditional South Indian cardamoms, and festive banqueting.",
    attire: "Cocktail Glamour & Royal Embroideries (Lehengas & Jodhpuri)",
    iconName: "Music"
  },
  {
    id: "wedding",
    title: "Sacred Muhurtham",
    date: "Dec 13th, 2024",
    time: "4:00 PM",
    venueName: "Lakeside Mandap",
    description: "Our sacred ceremony, celebrating South Indian wedding traditions under a dome of fresh jasmine blooms. Includes the playful 'Maalai Maatral' (garland exchange) and the tying of the Mangalsutra at sunset.",
    attire: "Traditional Silk Sarees (Kanchipuram Pattu) & Pure Ivory Veshtis",
    iconName: "Heart"
  },
  {
    id: "reception",
    title: "The Royal Banquet",
    date: "Dec 14th, 2024",
    time: "8:00 PM",
    venueName: "The Pichola Palace Terrace",
    description: "An opulent candlelight dinner and grand reception, honoring the newlyweds with classical veena fusion, champagne toasts, and dynamic global sitar orchestrations.",
    attire: "Royal Formal or Black Tie (Tuxedos & Heavily Styled Silk)",
    iconName: "Sparkles"
  }
];

export const GALLERY_MOMENTS: GalleryMoment[] = [
  {
    id: "pure_happiness",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuClsdiNw7cg1D_h9BFAXvpCvVW67AxCODKbm55nRxaQXLtlAcce0PacvzQKp69jC7ar5J4e11mDX4cnF4W0SIYAllOAffJYfApucdvLXDqLlCFq67IO6itW9TLnfAZ-QaZbVuj_-hE5waN2oNWXVYOlMDiwVX3FDKx42hIiXaVSR3Vq6it3CnNkgiYzLP6fcVU52obdvH1AoLyBKFUxp-JiCdubLb-2bmdLCkIN_xhpg2zH5hkyCrCvreyHXTAQ4wzJllfyr0y7c5c",
    title: "Pure Happiness",
    subtitle: "Exchanging laughter & sacred promises",
    depth: 0.12,
    gridSpan: "md:col-span-2 md:row-span-2"
  },
  {
    id: "palace_lighting",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCKjrzrdCzD_hwif6nKt1F73OTRzheSGj3AYri4Z-sJVTbCPNxePv_I3usWUObGN9-Hgrbk8Qv1PskN6QtTa1H7zotWhAlh1uQOfiSodlB7dwQTM3LAn8aCp_dWyMiR8Vo2IDSEjlyoeHSJ97uyQW_ffuOIPNf44rxPpawqR-8SLi7ZHoOBY54ysuN3gFGg6aWXS7iHlPMIJd-zTB1uUlV6qqwvyQFS8NwAbcP9t1H5Vrv84oqb5X_Efy68KzQL-empXcEWGSTMhL0",
    title: "Palace Lighting",
    subtitle: "Opulent settings & golden chandeliers",
    depth: -0.06,
    gridSpan: "md:col-span-2 md:row-span-1"
  },
  {
    id: "mehendi_detail",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAxN-_DmPLHHJBe-cX6MbhGxFBTvkybvcSRoN43UTfGhRJfx8NehiqdEemV14wsZE0S5dN8rVFL3B_UBPtBKS-3iLRTOmiNm52yFlTx3gTz-99mbZim9MTWnv0xCfodzjZornQHS_Me4W2sMOJPaNYzgk84RNtPlxAYQfSze8pbACH8bxUQ2TSxvhgfil67h5aWr2FggDogjr05iH_mWfD1Jm0YLF9ZffMV4pE6S8XXKuDUE_yD6lf1gXyxAGWRA5AHXxIl6bYZ3zY",
    title: "Henna Details",
    subtitle: "Organic luxury patterns & floral elements",
    depth: 0.18,
    gridSpan: "md:col-span-1 md:row-span-1"
  },
  {
    id: "sunset_walk",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBd2iZtW42a8rUgpZ9x-50vEdgTtCd_-nXUlWGBeCpQrLgMN1u-9XdEsW43qMOZ_8eTlcZcJGRCPbzkDSXvgKQP9n7B655Ngpucnv28E4Sk6fpyAqcpjowsJt1inAoCTf8-2vbnrYfaL8a1CkUqpR0xl4oxEbcYmnWO4jrr5fvKPgqtr7ZGJmFhbHAof5aETFoj9zTZVSnZDSuea21jWIdgwfXQcyCVdDjpvRUQTxlT4_z2-DGo-VB5uiYBiZDjitRXUwYEYSOt0wQ",
    title: "Evening Walk",
    subtitle: "Under Udaipur's romantic golden skies",
    depth: 0.05,
    gridSpan: "md:col-span-1 md:row-span-1"
  }
];

export const VENUE_DETAILS = {
  name: "The Oberoi Udaivilas",
  address: "Haridasji Ki Magri, Mulla Talai, Udaipur, Rajasthan 313001, India",
  description: "Located on the majestic banks of Lake Pichola, The Oberoi Udaivilas stands as a monument to India's royal legacy. Framed by symmetrical arches, reflection pools, and sprawling gold/ivory courtyards, it offers an matchless canvas for a traditional, timeless wedding.",
  photo1: "https://lh3.googleusercontent.com/aida-public/AB6AXuCgVV49zhZuQbkv13N2ctOJExS1FXyrgMcvTuRLrDveSSjfJLkfqWga4pjfCljHpbe20xG48zmfwf-omciEW_y2-_2EBTE9FUEPRMHpbxJ_Gp57CODz1zet1L1JVylHJAzCi4fAYmhLYAfmXJI5cTCKLnwJhv6DGvaO6zGay9lg9Po_H47n0fVvBmKUnh-oxv01j4UgCtBpdCCr-jIqFVstghEP1gYSQ7f-5RcsswHnPLTebujQVQHIt4JaBjBO0Ms8MAIDYg4GLR8",
  photo2: "https://lh3.googleusercontent.com/aida-public/AB6AXuCpO5bGc9X8230mOHX7SXlEPl3xN4ry-1_Iep5cfMliCeREJCpYtOyd92fEOnSrHEn8zdUa5jc-NZ3XW1OGO9TAJdSegf3Pth07HsXLJEDn_9SC6kpK0LsenpMZu1185fVLjSco_kvWkQS91hF2PEBuOBmgDzThYpnd6wdGQ79EDsoulgdLEDxMVJPYR1D7PHCPUJT-ETi8DQC3v7ePRpwY7wlZQL7ff4DCWrEKuNbF33KLc1xqLgy6DSpxhogMrK3mVo6FlYR95Oc",
  mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3628.1652758178877!2d73.6685810753625!3d24.583561978107406!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3967e54f9a00b8ef%3A0xc367688c2793132e!2sThe%20Oberoi%20Udaivilas%2C%20Udaipur!5e0!3m2!1sen!2sin!4v1715694200000!5m2!1sen!2sin",
  coupleStoryPhoto: "https://lh3.googleusercontent.com/aida-public/AB6AXuAwG7uE300byH75VtuU6uN9XLOV6R1twIuaM-fqifQ4Xm1ZBWcyJpI_WzugLEqNgJfliSLiRgnicOdOb0FOcSd82sm6T_Zv0XvrtUrO6hx5v0aqUEVqM3GenWHOKQLFwbP3-fGYMG2IT9VVUx03WjK6B3S23ibdmfDQr39YCuqReIv9-mCiSWXHWDNiVwv40hChipdWSnvYBjs10tao9CqmIBVAF7Xoc0_blX6SkRNnBj8pVQ4zwlpiMxsZyK4ow-QJPUCEeCDtZQY"
};
