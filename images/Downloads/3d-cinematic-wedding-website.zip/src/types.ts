/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface WeddingEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  venueName: string;
  description: string;
  attire: string;
  iconName: string;
}

export interface GalleryMoment {
  id: string;
  imageUrl: string;
  title: string;
  subtitle: string;
  depth: number; // For 3D parallax scroll offsets
  gridSpan: string; // Tailwind grid span classes
}

export interface GuestRSVP {
  id: string;
  name: string;
  attending: boolean;
  guestsCount: number;
  dietaryNotes: string;
  createdAt: string;
}
