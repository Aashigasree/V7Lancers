document.getElementById("loginForm").addEventListener("submit", function(e){
e.preventDefault();


const regno = document.getElementById("regno").value;
const password = document.getElementById("password").value;

fetch("/login", {
    method: "POST",
    headers:{
        "Content-Type":"application/json"
    },
    body: JSON.stringify({
        regno: regno,
        password: password
    })
})
.then(response => response.json())
.then(data => {
    if(data.status === "success"){
        window.location.href = "/dashboard";
    }else{
        document.getElementById("msg").innerText = "Invalid Register Number or Password";
    }
})
.catch(err=>{
    document.getElementById("msg").innerText = "Server error. Try again.";
});


});
